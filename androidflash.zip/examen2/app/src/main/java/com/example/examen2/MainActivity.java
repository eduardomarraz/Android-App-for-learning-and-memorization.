package com.example.examen2;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    TextView t1,t2,t3; EditText e1; Button b1,b2,b3, tema, preg; ImageView i1;
    int nt,np,t,p; int[] n={25,45,10,15,10}; String claveP,claveR; SharedPreferences pref =null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);
        Cover cover = new Cover();
        cover.show(getSupportFragmentManager(), "Cover"); //Trae y muestra el cuadro de instrucciones iniciales.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        ActionBar ab = getSupportActionBar();ab.hide();
        pref = getSharedPreferences("q", Context.MODE_PRIVATE);
        almacenar();
        e1 = findViewById(R.id.e1);i1 = findViewById(R.id.i1);
        t1 = findViewById(R.id.t1);t2 = findViewById(R.id.t2);t3 = findViewById(R.id.t3); tema = findViewById(R.id.tema);
        b1 = findViewById(R.id.b1);b2 = findViewById(R.id.b2);b3 = findViewById(R.id.b3); preg = findViewById(R.id.preg);
        claveP = "t1_p1"; claveR = "t1_r1";
        preg.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                p=0;
                preg.setText("Preg=?");
            return true;}});
        tema.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                t=0;
                tema.setText("Tema=?");
                return true;}});
    }
    public void almacenar() {
        File f= new File("/data/data/com.example.examen2/shared_prefs/q.xml");
        f.delete();
        int i,j,id1,id2, g; String s1,s2;
        SharedPreferences.Editor spe = pref.edit();
        for (j=1;j<(1+n.length);j++)     //Para cada uno de los temas j
            for (i=1;i<(1+n[j-1]);i++) { //Para cada una de los preguntas de cada tema
                s1="t"+j+"_p"+i; s2="t"+j+"_r"+i;
                id1 = this.getResources().getIdentifier(s1,"string", getPackageName()); //Para obtener el ID de la string s1
                id2 = this.getResources().getIdentifier(s2,"string", getPackageName());
                spe.putString(s1, getString(id1)); spe.putString(s2, getString(id2));} spe.commit();}

    public void preguntar(View v){
        t3.setText("");t2.setText("Empieza por...");e1.setText("");
        i1.setImageResource(0);
        int j=1+new Random().nextInt(n.length); //Elegimos un tema al azar del 1 al 5
        if(t>0) j=t; //Aqui pones fijo el tema que queremos
        int i=1+new Random().nextInt(n[j-1]);
        if(p>0) i=p; //Aqui pones fijo la pregunta que queremos
        claveP="t"+j+"_p"+i; claveR="t"+j+"_r"+i; String valor=pref.getString(claveP, "");
        t1.setText(valor);
        if(claveP.equals("t2_p22"))  i1.setImageResource(R.drawable.t2_f22);
        if(claveP.equals("t2_p23"))  i1.setImageResource(R.drawable.t2_f23);
        if(claveP.equals("t2_p24"))  i1.setImageResource(R.drawable.t2_f24);
        if(claveP.equals("t2_p25"))  i1.setImageResource(R.drawable.t2_f25);
        if(claveP.equals("t2_p26"))  i1.setImageResource(R.drawable.t2_f26);
        if(claveP.equals("t2_p27"))  i1.setImageResource(R.drawable.t2_f27);
        if(claveP.equals("t2_p28"))  i1.setImageResource(R.drawable.t2_f28);
    }
    public void validar(View v){
        String r = pref.getString(claveR, "");
        if( e1.getText().toString().equals(r)) {t2.setText("acertaste");}
        else{ t2.setText("fallaste");}}
    public void me_rindo(View v){
        String r = pref.getString(claveR, ""); t3.setText(r);}
    public void ayudar(View v){
        String r = pref.getString(claveR, ""); t3.setText(r.substring(0,3));}
    public void tema(View v){
        t++;
        if(t>5) t=0;
        tema.setText("Tema="+t);
        if(t==0) tema.setText("Tema=?");}
    public void preg(View v){
        p++;
        preguntar(v);
        if(t==0) if(p>45)p=0;
        if(t==1) if(p>n[0]) p=0; if(t==2) if(p>n[1]) p=0;
        if(t==3) if(p>n[2]) p=0; if(t==4) if(p>n[3]) p=0;
        if(t==5) if(p>n[4]) p=0;
        preg.setText("Preg="+p);
        if(p==0) preg.setText("Preg=?");}
}