package com.example.examen2;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class Cover extends DialogFragment {
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater(); //Esto coge el cover.xml y lo pasa al java mostrándolo en el renglón siguiente
        View view = inflater.inflate(R.layout.cover, null); //Genera un view con el cover.xml inflado
        builder.setView(view);                              //Construye la pagina con esta vista/widget para ponerla encima de la principal
        Button b0 = view.findViewById(R.id.b0);             //los relaciona
        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {dismiss();}});     //el botón cierra el cuadro de dialogo
        return builder.create();                            //Devuelve el cuadro de dialogo a la actividad principal
    }
}
